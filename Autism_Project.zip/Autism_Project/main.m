%% Map neurosynth terms to MMP atlas
%%
% add path
addpath ./functions
addpath ./Neurosynth_Terms
addpath ./Masks/

% Neurosynth and MMP atlas
neurosynthTermPath = fullfile('./Neurosynth_Terms','*nii.gz');
mmpAtlaFileName = 'HCP-MMP_in_MNI_corr_2mm.nii.gz';

% Map neurosynth terms on MMP atlas
outputDIR = './data';
prefix_name = 'neurosynth';
mapFunctoMMP(mmpAtlaFileName,neurosynthTermPath,prefix_name,outputDIR)

%% Map neurosyth term profile to surface
%%
% Get neurosyth term profile
load('mmp_neurosynth.mat')
% using PCA
[coeff,score,latent,tsquared] = pca(mmpFuncAll');
neurosynthProfile = coeff(:,2);
save(fullfile("./data","neurosynthProfileVar2.mat"),"neurosynthProfile")
latent_percent = latent ./ sum(latent);
plot(1:10,latent_percent(1:10),'o-','Color','red')

% assign neurosynthProfile to each of network
load("networkLabel.mat")
nets = Parcel_Net_ID;
net6NeurosynthProfile = assignParcelToNet(nets,neurosynthProfile);
save(fullfile("./data","net6NeurosynthProfileVar2.mat"),"net6NeurosynthProfile")

% using laplaciang eigen
[mappedX, mapping] = laplacian_eigen(mmpFuncAll, 20);
neurosynthProfileLap = -mappedX(:,1);

% spatial correlation between PCA and laplaciang eigen
[rPL,pPL] = spatialCorr(neurosynthProfile,neurosynthProfileLap);

% Map to MMP surfer
maskPath = './Masks';
func_label = '_NeurosythProfileVar2';
func = neurosynthProfile;
outputDIR = './Result_GII';

mmpSurfLabelFileLH = 'fsaverage_lh_HCP-MMP1.label.gii'; % lh
mmpSurfLabelFileRH = 'fsaverage_rh_HCP-MMP1.label.gii'; % rh

map_to_mmp_surf(mmpSurfLabelFileLH,func,func_label,maskPath,outputDIR) % lh
map_to_mmp_surf(mmpSurfLabelFileRH,func,func_label,maskPath,outputDIR) % rh

%% Related neurosyth term profile to cortical organization
%%
load('neurosynthProfile.mat')
neurosynthProfile = neurosynthProfile(1:180); % left hemisphere

% 1. Related neurosyth term profile to geodesic distance
addpath ./Masks/    % add path
addpath ./functions

% The file contains the coordinate infomation of MMP atlas
mmpAtlasFile = 'MMP_atlas_file.xlsx';

% ﻿Parcellated map of geodesic distance from primary visual cortical area V1.
D = spatialDist(mmpAtlasFile);

% Calculate correlation between neurosyth term profile and geodesic distance
[rGeoDis, pGeoDis] = spatialCorr(neurosynthProfile,D); % 1:180, left hemisphere

% 2. Related neurosyth term profile to T1w/T2w ratio
addpath ./data % add path

load('myelin_MMP_MTX.mat') % load T1w/T2w data

% The average of T1w/T2w
myelinMPP = mean(myelin_MMP_MTX,2);

% Calculate correlation between neurosyth term profile and T1w/T2w
[rMyelin,pMyelin] = spatialCorr(neurosynthProfile,myelinMPP(1:180));

% 3. Related neurosyth term profile to functional gradient
% load functional gradient
load("functionalGrad_MMP_MTX.mat")

% Calculate correlation between neurosyth term profile and functional gradient
[rFG,pFG] = spatialCorr(neurosynthProfile,mmp_func(1:180,2));

% 4. map D, T1w/T2w ratio and functional gradient to surface
maskPath = './Masks';
func_label = '_Myelin';
func = myelinMPP;
outputDIR = './Result_GII';

mmpSurfLabelFileLH = 'fsaverage_lh_HCP-MMP1.label.gii'; % lh
map_to_mmp_surf(mmpSurfLabelFileLH,func,func_label,maskPath,outputDIR) % lh

%% Related neurosynth terms with autism-related gene expression profiles
%%
% add path
addpath ./data/
addpath ./functions/
addpath ./GeneprocessedData/

% load data
load('neurosynthProfileVar2.mat') % neurosynth profile
load ('100DS360scaledRobustSigmoidNSGRNAseqQC1Lcortex_ROI_NOdistCorrEuclidean.mat') % gene data
load('GeneSymbol.mat') % gene ID

indGene = find(~isnan(parcelExpression(:,2))); % index of nonNaN in parcel gene expression
parcelExpressionEX = parcelExpression(indGene,2:end); % gene expression excluded with NaN
mmpNeurosynth = neurosynthProfile(indGene,:);
save(fullfile("./GeneprocessedData/","indGene.mat"),"indGene")

% PLS analysis
PLS_Stat = PLS_bootstrap_hs(parcelExpressionEX,GeneSymbol,mmpNeurosynth);
myStats = PLS_calculate_stats_hs(parcelExpressionEX,mmpNeurosynth);
save(fullfile('./PLS','PLS_Var2.mat'),"PLS_Stat")
save(fullfile('./PLS','myStats_Var2.mat'),"myStats")

% Correlations between neurosynth terms and PLS score
load('mmp_neurosynth.mat')
load("PLS_Var2.mat")
load("indGene.mat")
mmpNeurosynthTerm = mmpFuncAll(indGene,:);
[rNeuTerm,pNeuTerm] = corr(mmpNeurosynthTerm,PLS_Stat.XS(:,2));
rNeuTerm = abs(rNeuTerm);
tlb = readtable("WorldCloud_NeurosynthTerm_PLS2Var2.xlsx");
figure
wordcloud(tlb,'Word','Coeficient','Color','#0072BD','HighlightColor','#0072BD'); % plot
wordcloud(tlb,'Word','Coeficient','Color','#D95319','HighlightColor','#D95319'); % plot


% Enrichment analysis 
load('Candidate_gene.mat')
load(fullfile('./PLS','PLS.mat'))
disease_GeneName = {'Depression_gene','Bipolar_gene','Autism_gene',...
  'Schizophrenia_gene','Intellectual_disability_gene','Epilepsy_gene'};
disease_GeneName = disease_GeneName';

CandGene_ER = zeros(length(disease_GeneName),1);
CandGene_P = zeros(length(disease_GeneName),1);
plsW_Perm_All = cell(1,length(disease_GeneName));
candGeneWAll = zeros(1,length(disease_GeneName));
for i = 1:length(disease_GeneName)
    eval(['CandGene = Candidate_gene.',disease_GeneName{i},';'])
    [p,ER,CAND_PLSwe,perm_PLSw] = PLS_candidate_genes_ER(PLS_Stat.pls2,CandGene);
    CandGene_ER(i) = ER;
    CandGene_P(i) = p;
    plsW_Perm_All{i} = perm_PLSw;
    candGeneWAll(i) = CAND_PLSwe;
end
CandGene_q = mafdr(CandGene_P,'BHFDR',true);
logFDR = -log10(CandGene_q);

pls2ER = struct();
pls2ER.candGeneER = CandGene_ER;
pls2ER.candGeneP = CandGene_P;
pls2ER.candGeneQ = CandGene_q;
pls2ER.candGenelogFDR = logFDR;
pls2ER.diseaseName = disease_GeneName;
pls2ER.plswPerm = plsW_Perm_All;
pls2ER.candGeneW = candGeneWAll;
save("pls2ER_Var2.mat","pls2ER")

% Map PLS-1 and -2 to surface
load("PLS.mat")
load("indGene.mat")
maskPath = './Masks';
func_label = '_PLS2Var2_thred';
plsScore = zeros(1,180);
plsScore(indGene) = PLS_Stat.XS(:,2); plsScore(abs(plsScore) <= 0.01) = 0;
func = plsScore;
outputDIR = './Result_GII';

mmpSurfLabelFileLH = 'fsaverage_lh_HCP-MMP1.label.gii'; % lh
map_to_mmp_surf(mmpSurfLabelFileLH,func,func_label,maskPath,outputDIR) % lh

% plot
load("pls1ER.mat")
pls1PermW = pls2ER.plswPerm{3}; % Autism PLS perm W
%histogram(pls1PermW)
h = histfit(pls1PermW,50,'normal');
hold on
x = pls2ER.candGeneW(3);
line([x x],[0 600],'Color',[.7 .7 .7],'LineWidth',1.5) % Autism ER
h(1).FaceColor = [0 0.4470 0.7410];
h(2).Color = [.9 .5 .4];


%% Spatial-temporal tractory of gene expression (PLS)
%%
% add path
addpath ./BrainSpan
addpath ./PLS
addpath ./functions

% load data
load("GeneExp_BS.mat")
load("PLS.mat")
BrainspanInfo = importfile_BrainspanInfo('mRNA-seq_Sample metadata.xlsx');
save(fullfile('./BrainSpan','BrainspanInfo.mat'),'BrainspanInfo')

% Spatial-temporal tractory 
OutputDIR = './PLS';
plsResults = cell(1);
plsResults{1} = PLS_Stat;
CortRegions = {'OFC','DFC','VFC','MFC','M1C','S1C','A1C','STC','ITC','IPC','V1C','M1CS1C','PC','TC','OC'};
[GE_WEIGHTED_PLS1,GE_WEIGHTED_PLS2] = spatiotemporalTrac(plsResults,GeneExp_BS,BrainspanInfo,CortRegions);
save(fullfile(OutputDIR,'GE_WEIGHTED_PLS1Var2.mat'),'GE_WEIGHTED_PLS1')
save(fullfile(OutputDIR,'GE_WEIGHTED_PLS2Var2.mat'),'GE_WEIGHTED_PLS2')

%% SVM analysis using autism fMRI data
%%
% add path
addpath ./functions
addpath ./SVM_Train
addpath ./GeneprocessedData
addpath ./PLS

% load data
load("feature_ReHo.mat")
load("label_ReHo.mat")
load("indGene.mat")
load("PLS.mat")

% SVM classification
labels = label_ReHo;
features = feature_ReHo(:,indGene);
nfold = 10;

setThreshed = [0,0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1]; % threshed of gene expression (PLS-1 or -2)
accuracyAll = zeros(1,length(setThreshed));
indRegionThdAll = cell(1,length(setThreshed));
for iThd = 1:length(setThreshed)
    indRegion = find(abs(PLS_Stat.XS(:,2)) > setThreshed(iThd));
    indRegionThdAll{iThd} = indRegion;
    featuresThd = features(:,indRegion);
    [accuracyAll(iThd),~,~] = SVM_Classify(featuresThd,labels,nfold);
end
save(fullfile("./SVM_Train","accuracyAllReHo_PLS2Var2.mat"),"accuracyAll")
save(fullfile("./SVM_Train","indRegionThdAll_PLS2Var2.mat"),"indRegionThdAll")

% permutation
load("indRegionThdAll_PLS2Var2.mat")
labels = label_ReHo;
features = feature_ReHo(:,indGene);
nfold = 10;

CoreNum = 10; % the number of core was used
if isempty(gcp)
    parpool(CoreNum)
end

accuPerAll = cell(1,length(indRegionThdAll));
for iRegThd = 1:length(indRegionThdAll)
    featuresThd = features(:,indRegionThdAll{iRegThd});
    accuPer = zeros(1,1000);
    hbar = parfor_progressbar(1000,'Please wait...'); 
    parfor jPer = 1:1000 % Permutation 1000 times
        order = randperm(length(labels));
        labelsRand = labels(order);
        [accuPer(jPer),~,~] = SVM_Classify(featuresThd,labelsRand,nfold);
        hbar.iterate(1);
    end
    accuPerAll{iRegThd} = accuPer;
    close(hbar); % Clean up
end
save(fullfile('./SVM_Train','accuPerAll_PLS2Var2.mat'),'accuPerAll')

% Statistical significance of accuracy
load("accuPerAll_PLS2Var2.mat")      % load permutation accuracy
load("accuracyAllReHo_PLS2Var2.mat") % load accuracy

P_Perm = zeros(1,length(accuracyAll));
for iAccu = 1:length(accuracyAll)
    P_Perm(iAccu) = length(find(accuPerAll{iAccu} > accuracyAll(iAccu))) / 1000;
end
save(fullfile("./SVM_Train","P_Perm_PLS2Var2.mat"),"P_Perm")

% Map to Surfer
load("indGene.mat")
load("indRegionThdAll.mat")
load("PLS.mat")
load("accuPerAll.mat")
load("accuracyAllReHo.mat")

pls1Thrd_lh = zeros(1,180);
pls1Score = PLS_Stat.XS(:,1);
pls1Thrd = zeros(1,length(pls1Score));
pls1Thrd(indRegionThdAll{8}) = pls1Score(indRegionThdAll{8}); % the highest accuracy
pls1Thrd_lh(indGene) = pls1Thrd;

accuPermHighest = accuPerAll{8};
%histogram(pls1PermW)
h = histfit(accuPermHighest);
hold on
x = accuracyAll(8);
line([x x],[0 100],'Color',[.7 .7 .7],'LineWidth',1.5) % Autism ER
h(1).FaceColor = [0.6 0.7 0.9];
h(2).Color = [0.5 0.7 0.9];

maskPath = './Masks';   % Map to Surfer
func_label = '_PLS1_ThdHighAccuracy';
func = pls1Thrd_lh;
outputDIR = './Result_GII';

mmpSurfLabelFileLH = 'fsaverage_lh_HCP-MMP1.label.gii'; % lh
map_to_mmp_surf(mmpSurfLabelFileLH,func,func_label,maskPath,outputDIR) % lh

%% Correlate threshed feature with autism behaviors
%%
addpath ./Clin_Info/
tlb = readtable("NYU_ABIDE.xlsx");
load("feature_ReHo.mat")
reho_posthd = mean(feature_ReHo(1:79,find(pls1Thrd_lh > 0)),2);
reho_negthd = mean(feature_ReHo(1:79,find(pls1Thrd_lh < 0)),2);
behaviorAutism = [tlb.FIQ,tlb.VIQ,tlb.PIQ,tlb.ADOS_COMM,tlb.ADOS_SOCIAL,tlb.ADOS_STEREO_BEHAV,...
    tlb.AGE_AT_SCAN];
% behaviorAutism = [tlb.ADI_R_SOCIAL_TOTAL_A,tlb.ADI_R_VERBAL_TOTAL_BV,tlb.ADI_RRB_TOTAL_C,...
%     tlb.ADI_R_ONSET_TOTAL_D,tlb.FIQ,tlb.VIQ,tlb.PIQ,tlb.AGE_AT_SCAN];
behaviorAutism = behaviorAutism(1:79,:);
% indBeha = find(behaviorAutism(:,1) ~= -9999);
% behaviorAutism = behaviorAutism(indBeha,:);
% reho_posthd = reho_posthd(indBeha);
% reho_negthd = reho_negthd(indBeha);
[rBehavPos,pBehavPos] = corr(behaviorAutism,reho_posthd);
[rBehavNeg,pBehavNeg] = corr(behaviorAutism,reho_negthd);

%% Classify network
%%
% addpath
addpath ./functions
addpath ./Masks

% load mmp atlas and network label
mmpAtalasFile = load_untouch_nii('MNI_Glasser_HCP_v1.0_3mm.nii.gz');
mmpAtalasImg = mmpAtalasFile.img;
load('networkLabel.mat')

% set director path
fMRIPath = './data/FunImgARCWF';
fMRIDir = dir(fullfile(fMRIPath));

nfold = 10;
labels = Parcel_Net_ID;
testLabelSubjects = cell(1,length(fMRIDir)-2);
predLabelSubjects = cell(1,length(fMRIDir)-2);
accuracySubjects = zeros(1,length(fMRIDir)-2);

CoreNum = 10; % the number of core was used
if isempty(gcp)
    parpool(CoreNum)
end

hbar = parfor_progressbar(1000,'Please wait...'); 
parfor iDir = 3:length(fMRIDir)
    subNifti = load_untouch_nii(fullfile(fMRIDir(iDir).folder,fMRIDir(iDir).name,'Filtered_4DVolume.nii'));
    subImg = subNifti.img;
    tsMMP = process_fMRI(subImg, mmpAtalasImg);
    features = tsMMP';
    [accu,testLabelAll,predLabelAll] = SVM_Classify(features,labels,nfold);
    testLabelSubjects{iDir-2} = testLabelAll;
    predLabelSubjects{iDir-2} = predLabelAll;
    accuracySubjects(iDir-2) = accu;
    hbar.iterate(1);
end
close(hbar); 

save(fullfile("./NetClassification","accuracySubjects.mat"),"accuracySubjects")
save(fullfile("./NetClassification","testLabelSubjects.mat"),"testLabelSubjects")
save(fullfile("./NetClassification","predLabelSubjects.mat"),"predLabelSubjects")

for i = 30:30
    figure
    plot(1:160,features(i,:),'green','LineWidth',3)
    axis off
end


%% confusion matrix
%%
% add path
addpath ./NetClassification/

% load data
load("predLabelSubjects.mat")
load("testLabelSubjects.mat")
confusionMatrixSubs = cell(1,length(testLabelSubjects));
for itest = 1:length(testLabelSubjects)
    testSubLabels = testLabelSubjects{itest};
    predSubLabels = predLabelSubjects{itest};

    netID = unique(testSubLabels);
    confusionMatrix = [];
    for inet = 1:length(netID)
        idxnet = find(testSubLabels == netID(inet));
        predNetLabels = predSubLabels(idxnet);
        accuNet = zeros(1,length(netID));
        for jnet = 1:length(netID)
            accuNet(jnet) = length(find(predNetLabels == netID(jnet)))/length(predNetLabels);
        end
        confusionMatrix = [confusionMatrix;accuNet];
    end
    confusionMatrixSubs{itest} = confusionMatrix;
end
save(fullfile("./NetClassification","confusionMatrixSubs.mat"),"confusionMatrixSubs")

% statistical analysis
load("confusionMatrixSubs.mat")
confusionMatrixSubs{136} = {}; % 异常数据
confusionMatrixSubs{164} = {};
netAccuNet1 = [];
netAccuNet2 = [];
netAccuNet3 = [];
netAccuNet4 = [];
netAccuNet5 = [];
netAccuNet6 = [];
for isub = 1:length(confusionMatrixSubs)
    if isempty(confusionMatrixSubs{isub})
        continue
    else
        sub_confusionMatrix = confusionMatrixSubs{isub};
        netAccuNet1 = [netAccuNet1;sub_confusionMatrix(1,:)];
        netAccuNet2 = [netAccuNet2;sub_confusionMatrix(2,:)];
        netAccuNet3 = [netAccuNet3;sub_confusionMatrix(3,:)];
        netAccuNet4 = [netAccuNet4;sub_confusionMatrix(4,:)];
        netAccuNet5 = [netAccuNet5;sub_confusionMatrix(5,:)];
        netAccuNet6 = [netAccuNet6;sub_confusionMatrix(6,:)];
    end
end
netAccuNetConfusionMatAll = struct();
netAccuNetConfusionMatAll.netAccuNet1 = netAccuNet1;
netAccuNetConfusionMatAll.netAccuNet2 = netAccuNet2;
netAccuNetConfusionMatAll.netAccuNet3 = netAccuNet3;
netAccuNetConfusionMatAll.netAccuNet4 = netAccuNet4;
netAccuNetConfusionMatAll.netAccuNet5 = netAccuNet5;
netAccuNetConfusionMatAll.netAccuNet6 = netAccuNet6;
save(fullfile("./NetClassification","netAccuNetConfusionMatAll.mat"),"netAccuNetConfusionMatAll")

% Plot
% data in a matrix (+ grouping indices)
data = netAccuNetConfusionMatAll.netAccuNet6;
group_inx = [ones(1,79), 2.*ones(1,103)];

group_names = {'Autism', 'Healthy control'};
condition_names = {'FTC', 'TPC', 'ADC', 'SMC', 'POC', 'VSC'};

% an alternative color scheme for some plots
c =  [0.45, 0.80, 0.69;...
      0.98, 0.40, 0.35;...
      0.55, 0.60, 0.79;...
      0.90, 0.70, 0.30]; 

figure
h = daviolinplot(data,'groups',group_inx,'outsymbol','k+',...
    'boxcolors','same','scatter',1,'jitter',1,'xtlabels', condition_names,...
    'legend',group_names);
ylabel('Accuracy');
xl = xlim; xlim([xl(1)-0.1, xl(2)+0.2]); % make more space for the legend
set(gca,'FontSize',10);

% statistical 
data = netAccuNetConfusionMatAll.netAccuNet2;
[h,p,ci,stats] = ttest2(data(1:79,:),data(80:end,:));



