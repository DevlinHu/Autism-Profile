function mapFunctoMMP(mmpAtlas,funcPath,prefix_name,outputDIR)
% This function is to map functional parameters to MMP atlas
% mmp_atlas: MMP atlas file name (nifti)
% funct_Path: functional parameters path (fALFF and ReHo)
% output_DIR: output director path

% load mmp atlas
mmp_nift = load_untouch_nii(mmpAtlas);
mmp_img = mmp_nift.img;

% extract subregion number
mmp_numb = unique(mmp_img);
mmp_numb = mmp_numb(2:end);

% functional parameter director
func_dir = dir(funcPath);
mmpFuncAll = [];
for i = 1:length(func_dir)
    indv_filename = func_dir(i).name;
    % split_filename = split(indv_filename,'.');
    % prefix_name = split_filename{1};
    
    % load functional parameter file
    func_nift = load_untouch_nii(indv_filename);
    func_img = func_nift.img;
    
    mmp_func = zeros(length(mmp_numb),1);
    for j = 1:length(mmp_numb)
        % extract functional parameter for each subregion
        subr_indx = find(mmp_img == mmp_numb(j));
        subr_func = func_img(subr_indx);
        % remove non-zero values
        subr_idx = find(subr_func);
        subr_nonzero_func = subr_func(subr_idx);
        % calculate mean value of func for each subregion
        subr_mean_func = mean(subr_nonzero_func);
        % mmp_func(j,1) = mmp_numb(j);
        mmp_func(j) = subr_mean_func;
    end
    mmpFuncAll = [mmpFuncAll,mmp_func];
end
save(fullfile(outputDIR,['mmp_',prefix_name,'.mat']),'mmpFuncAll')
