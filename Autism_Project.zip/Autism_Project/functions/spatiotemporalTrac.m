function [GE_WEIGHTED_PLS1,GE_WEIGHTED_PLS2] = spatiotemporalTrac(PLS,GE_BS,BS_Info,CortRegions)
% This function is to calculate spatiotemporal tractory for pls component
% got from pls analysis between neuroimage and gene expression (AHBA)
% This spatiotemporal profile, defined as the regional average of each gene’s
% expression level weighted by its bootstrap weight, was obtained across 
% cortical regions and time points based on major neurodevelopmental 
% milestones derived from whole-brain transcriptomic signatures
% INPUTs:
%        PLS - pls results
%        GE_BS - gene expression from brainspan
%        BS_Info - donor's sample information of brainspan
%        CortRegions - cortical regions of brain samples in brainsapn
% OUTPUTs:
%         GE_WEIGHTED_PLS1 - regional average of weighted gene expression
%         of PLS-1 in brain span
%         GE_WEIGHTED_PLS2 - regional average of weighted gene expression
%         of PLS-2 in brain span

% Extract gene weight for overlapped gene symbol
W_PLS1_OV_ALL = cell(length(PLS),1);
W_PLS2_OV_ALL = cell(length(PLS),1);
for i = 1:length(PLS)
    gene_symbol_pls1 = PLS{i}.pls1.gene;
    gene_symbol_pls2 = PLS{i}.pls2.gene;
    w_pls1 = PLS{i}.pls1.W;
    w_pls2 = PLS{i}.pls2.W;
    
    gene_symbol_ov = GE_BS.overlapped_gene;
    
    pls1_ind = [];
    for j = 1:length(gene_symbol_ov)
        for k = 1:length(gene_symbol_pls1)
            if strcmp(gene_symbol_ov(j),gene_symbol_pls1(k))
                pls1_ind = [pls1_ind;k];
                break
            end
        end
    end
    w_pls1_ov = w_pls1(pls1_ind);
    W_PLS1_OV_ALL{i} = w_pls1_ov;
    clear j k
    
    pls2_ind = [];
    for j = 1:length(gene_symbol_ov)
        for k = 1:length(gene_symbol_pls2)
            if strcmp(gene_symbol_ov(j),gene_symbol_pls2(k))
                pls2_ind = [pls2_ind;k];
                break
            end
        end
    end
    w_pls2_ov = w_pls2(pls2_ind);
    W_PLS2_OV_ALL{i} = w_pls2_ov;
end
clear i j k

header = GE_BS.header(2:end);
GE_WEIGHTED_PLS1 = cell(1,length(W_PLS1_OV_ALL));
GE_WEIGHTED_PLS2 = cell(1,length(W_PLS2_OV_ALL));
for i = 1:length(W_PLS1_OV_ALL)
    ge_weighted_pls1 = mean(repmat(W_PLS1_OV_ALL{i},1,size(GE_BS.geneExp_bs,2)) .* GE_BS.geneExp_bs);
    ge_weighted_pls2 = mean(repmat(W_PLS2_OV_ALL{i},1,size(GE_BS.geneExp_bs,2)) .* GE_BS.geneExp_bs);
    
    braincode = BS_Info.(2);
    ge_weighted_braincode_pls1_ALL = [];
    ge_weighted_braincode_pls2_ALL = [];
    for j = 1:length(braincode)
        ge_weighted_braincode_pls1 = zeros(1,length(CortRegions));
        ge_weighted_braincode_pls2 = zeros(1,length(CortRegions));
        for k = 1:length(CortRegions)
            braincode_gene = [char(braincode(j)),char(CortRegions{k})];
            for l = 1:length(header)
                if strcmp(braincode_gene,header(l))
                    ge_weighted_braincode_pls1(k) = ge_weighted_pls1(l);
                    ge_weighted_braincode_pls2(k) = ge_weighted_pls2(l);
                    break
                end
            end
        end
    ge_weighted_braincode_pls1_ALL = [ge_weighted_braincode_pls1_ALL;ge_weighted_braincode_pls1];
    ge_weighted_braincode_pls2_ALL = [ge_weighted_braincode_pls2_ALL;ge_weighted_braincode_pls2];
    end
    GE_WEIGHTED_PLS1{i} = ge_weighted_braincode_pls1_ALL;
    GE_WEIGHTED_PLS2{i} = ge_weighted_braincode_pls2_ALL;
end

