function [r,p] = spatialCorr(spatialPatt1, spatialPatt2)
% This function is to calculate spatial correlation between two spatial
% parameters
% INPUTs:
%        spatialPatt1--the first spatial parameter
%        spatialPatt2--the second spatial parameter
% OUTPUTs:
%         r--correlation coeficient
%         p--p value of correlation got from permutaion analysis

r = corr(spatialPatt1,spatialPatt2,'type','Spearman');

% Permutation
rPer = zeros(1,10000);
for iPer = 1:10000 % permutation time
    order = randperm(length(spatialPatt1));
    spatialPatt1Per = spatialPatt1(order);
    rPer(iPer) = corr(spatialPatt1Per,spatialPatt2, 'type','Spearman');
end
p = length(find(abs(rPer) > abs(r))) / 10000;