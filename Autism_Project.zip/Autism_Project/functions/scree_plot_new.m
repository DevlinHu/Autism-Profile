function h = scree_plot_new(lambdas1,title_s)
% SCREE_PLOT   Plot of the scaled eigenvalues. 
%
%   h = SCREE_PLOT(lambdas) plots the eigenvalues corresponding to a
%   gradient. Lambdas are scaled to a sum of 1. All graphics objects
%   created are stored in structure array h. 
%
%   For more information, please consult our <a
%   href="https://brainspace.readthedocs.io/en/latest/pages/matlab_doc/visualization/scree_plot.html">ReadTheDocs</a>.


h.figure = figure('Color','White');
h.axes = axes(); 
h.plot = plot(lambdas1,'o-','Color','k');
% hold on
% h.plot = plot(lambdas2,'o-','Color','r');
xlabel('Components');
ylabel('Explained variance');
% xlabel('PLS Component');
% ylabel('Explained variance');
title(title_s)
% legend('HC','WD')
set(h.axes,'box','off','FontName','DroidSans','FontSize',14)