function probValueMMP = calculateProbMap(neurosynthTermPath,mmpAtlaFileName)
% INPUTs:
%       neurosynthTermPath: The file path of neurosynth cognitive terms
%       mmpAtlaFileName: The MMP atlas file name
% OUTPUTs:
%       probValueMMP: The probability value that projects to mmp atlas

mmpAtlaFileNifti = load_untouch_nii(mmpAtlaFileName);
mmpAtlaFileImg = mmpAtlaFileNifti.img;
mmpInd = unique(mmpAtlaFileImg);
mmpInd = mmpInd(2:end);

neurosynthTermDir = dir(fullfile(neurosynthTermPath,'*.nii.gz'));

% Calculate probility map of neurosynth terms
neusyProbImg = zeros(size(mmpAtlaFileImg));
for iNeusth = 1:length(neurosynthTermDir)
    neusyNifti = load_untouch_nii(neurosynthTermDir(iNeusth).name);
    neusyImg = neusyNifti.img;
    neusyImg(neusyImg < 0) = 0;
    neusyInd = find(neusyImg);
    neusyImg(neusyInd) = 1;
    neusyProbImg = neusyProbImg + neusyImg;
end
neusyProbImg = neusyProbImg ./ length(neurosynthTermDir);

% Project probility map to MMP atlas
probValueMMP = zeros(length(mmpInd),1);
for iMMP = 1:length(mmpInd)
    mmpIdx = find(mmpAtlaFileImg == mmpInd(iMMP));
    mmpSubProbValue = neusyProbImg(mmpIdx);
    nzIdx = find(mmpSubProbValue);

    if ~isempty(nzIdx)
        mmpSubProbValue = mmpSubProbValue(nzIdx);
        probValueMMP(iMMP) = mean(mmpSubProbValue);
    else
        continue
    end
end
