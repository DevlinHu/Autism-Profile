function netFunPara = assignParcelToNet(netLabel,funPara)
% This function is to assign functional parameter of each parcel to
% specific network
% INPUTs:
%        netLabel--network label correspond to each parcel
%        funPara--functional parameter in parcel space
% OUTPUTs:
%         netFunPara--functional parameters assign to each network

% identify network
% parceltoNet_id = zeros(length(funPara),1);
% for i = 1:length(funPara)
%     parceltoNet_id(i) = netLabel{i,2};
% end

netNum = unique(netLabel);
netFunPara = cell(1,length(netNum));
for iNet = 1:length(netNum)
    subNet_id = find(netLabel == netNum(iNet));
    netFunPara{iNet} = funPara(subNet_id);
end