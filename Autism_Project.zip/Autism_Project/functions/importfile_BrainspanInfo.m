function mRNAseqSamplemetadata = importfile_BrainspanInfo(workbookFile, sheetName, dataLines)
%IMPORTFILE 导入电子表格中的数据
%  MRNASEQSAMPLEMETADATA = IMPORTFILE(FILE) 读取名为 FILE 的 Microsoft Excel
%  电子表格文件的第一张工作表中的数据。  以表形式返回数据。
%
%  MRNASEQSAMPLEMETADATA = IMPORTFILE(FILE, SHEET) 从指定的工作表中读取。
%
%  MRNASEQSAMPLEMETADATA = IMPORTFILE(FILE, SHEET,
%  DATALINES)按指定的行间隔读取指定工作表中的数据。对于不连续的行间隔，请将 DATALINES 指定为正整数标量或 N×2
%  正整数标量数组。
%
%  示例:
%  mRNAseqSamplemetadata = importfile("/Users/husheng/Desktop/HS/Project/Striatum_myelin/BrainSpan/mRNA-seq_Sample metadata.xlsx", "RNA-seq metadata", [6, 46]);
%
%  另请参阅 READTABLE。
%
% 由 MATLAB 于 2023-10-29 09:38:05 自动生成

%% 输入处理

% 如果未指定工作表，则将读取第一张工作表
if nargin == 1 || isempty(sheetName)
    sheetName = 1;
end

% 如果未指定行的起点和终点，则会定义默认值。
if nargin <= 2
    dataLines = [6, 46];
end

%% 设置导入选项并导入数据
opts = spreadsheetImportOptions("NumVariables", 12);

% 指定工作表和范围
opts.Sheet = sheetName;
opts.DataRange = "A" + dataLines(1, 1) + ":L" + dataLines(1, 2);

% 指定列名称和类型
opts.VariableNames = ["Window", "Braincode", "Hemisphere", "Age", "Days", "Sex", "Ethnicity", "PMI", "pH", "RIN", "DissectionScore", "SequencingSite"];
opts.VariableTypes = ["double", "string", "categorical", "string", "double", "categorical", "categorical", "double", "double", "double", "double", "categorical"];

% 指定变量属性
opts = setvaropts(opts, ["Braincode", "Age"], "WhitespaceRule", "preserve");
opts = setvaropts(opts, ["Braincode", "Hemisphere", "Age", "Sex", "Ethnicity", "SequencingSite"], "EmptyFieldRule", "auto");

% 导入数据
mRNAseqSamplemetadata = readtable(workbookFile, opts, "UseExcel", false);

for idx = 2:size(dataLines, 1)
    opts.DataRange = "A" + dataLines(idx, 1) + ":L" + dataLines(idx, 2);
    tb = readtable(workbookFile, opts, "UseExcel", false);
    mRNAseqSamplemetadata = [mRNAseqSamplemetadata; tb]; %#ok<AGROW>
end

end