function y = process_fMRI(fmData, atlas)
% This script dose some additional processing steps on the rsfMRI data
% INPUT:
% fmData: the fMRI data 
% atlas: the atlas and the dimension is the same as fmData 
% OUTPUT:
% y: fMRI time series which assigns to each parcel

% The index of atlas
idxAtlas = find(atlas);
indPar_Atlas = atlas(idxAtlas);

% the index of each pacel
indPar = unique(indPar_Atlas);


T = size(fmData,4); % number of time points of fMRI
x = zeros(T,length(idxAtlas));

% convert 4D fmri data to 2D matrix
for i = 1:T
    tmp = fmData(:,:,:,i);
    x(i,:) = tmp(idxAtlas);
end
clear i

% assign each voxel to a given pacel
y = zeros(T,length(indPar));
for i = 1:length(indPar)
    idxParcel = find(indPar_Atlas == indPar(i));
    x_subPar = x(:,idxParcel);
    x_subPar = x_subPar(:, ~any(isnan(x_subPar), 1)); % 删除包含NaN值的列
    y(:,i) = mean(x_subPar,2);
end

clear fmData;

% Demean
y = detrend(y,'constant'); 
y = y./repmat(std(y),T,1); %remove mean and make std=1
end

