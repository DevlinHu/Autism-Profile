function D = spatialDist(mmpAtlasFile)
% Showing anterior-posterior axis of cortex, which calculated as distance
% between each cortical parcel and the most posterior region (V1)
% INPUT:
%       MMPatlasfile - the detail information of MMP atlas (xslx)
% OUTPUT:
%        D - distances from the most posterior region to each parcel

% load MMP information
T = importfile_MMPInfo(mmpAtlasFile);

% extract coordinate axis
X = T.(10);
Y = T.(11);
Z = T.(12);

par_id = size(T,1);

% left hemispheral coordinate
X_L = X(1:par_id/2);
Y_L = Y(1:par_id/2);
Z_L = Z(1:par_id/2);

% the coordinate of the most posterior region (left VI)
x_max = X(1);
y_max = Y(1);
z_max = Z(1);

% calculate distance
D = sqrt((X_L-x_max).^2 + (Y_L-y_max).^2 + (Z_L-z_max).^2);

