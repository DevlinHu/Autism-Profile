function [accu,testLabelAll,predLabelAll] = SVM_Classify(features,labels,nfold)
% This function is to classify neuropsychiatric disease from healthy
% controls
% INPUTs
%        FCMat_Path: Path of functional connectivity matrix
%        label: label for svm train
%        circuit_Mask: the cerebral mask was used to extract FC feature
% OUTPUTs
%        accuracy: the classification accuracy

% features and labels
labels = double(labels);
features = double(features);

% SVM train
indices = crossvalind('Kfold',labels,nfold);
testLabelAll = [];
predLabelAll = [];
for i = 1:nfold
    test_idx = (indices == i);
    train_idx = ~test_idx;
        
    train_data = features(train_idx,:);
    train_label = labels(train_idx);
    
    test_data = features(test_idx,:);
    test_label = labels(test_idx);
    testLabelAll = [testLabelAll;test_label];
    
    %%% linear kernal
    [bestacc,bestc] = SVMcgForClass_NoDisplay_linear(train_label,train_data,-10,10,5,0.2);
    cmd = ['-t 0 ', '-h 0', ' -c ',num2str(bestc)];
        
    model = svmtrain(train_label,train_data, cmd);
    [predicted_label, accuracy, deci_value] = svmpredict(test_label,test_data,model);
    predLabelAll = [predLabelAll;predicted_label];
    accu_nfold(i) = accuracy(1);
end
accu = mean(accu_nfold);
