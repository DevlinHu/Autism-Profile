function myStats = PLS_calculate_stats_hs(parcelExpression,func_Para)
% Define the PLS calculate function with the following arguments
% parcelExpression: used as predictor for plsregression
% func_Para: used as response valuable for plsregression
% outputdir: the path where to save PLS results

disp('Re-run PLS to get explained variance and associated stats')

%DO PLS in 2 dimensions (with 2 components)
X = parcelExpression;
Y = func_Para;

dim = 10;
dim1=2;
[XL,YL,XS,YS,BETA,PCTVAR,MSE,stats]=plsregress(X,Y,dim);

temp=cumsum(100*PCTVAR(2,1:dim1));
Rsquared = temp(dim1);
PCTVAR = PCTVAR(2,:);
% R = corr(XS(:,1:dim1),Y);
% R_squ = R(1)^2 + R(2)^2;

%assess significance of PLS result
PCTVAR_PEM = [];
for j=1:1000
%     func_Para_tem = func_Para(order,:);
%     Yp=func_Para_tem(1:size(Y,1),:);
    order = randperm(size(Y,1));
    Yp = Y(order,:);
    [XLr,YLr,XSr,YSr,BETAr,PCTVARr,MSEr,statsr]=plsregress(X,Yp,dim);
    temp=cumsum(100*PCTVARr(2,1:dim1));
    Rsq(j) = temp(dim1);
    PCTVAR_PEM = [PCTVAR_PEM;PCTVARr(2,:)];
%     R_perm = corr(XSr(:,1:dim1),Yp);
%     R_squ_perm(j) = R_perm(1)^2 + R_perm(2)^2;
end
p=length(find(Rsq>=Rsquared))/j;
% p = length(find(R_squ_perm > R_squ)) / j;

% plot histogram
% hist(Rsq,30)
% hold on
% plot(Rsquared,20,'.r','MarkerSize',15)
% set(gca,'Fontsize',14)
% xlabel('R squared','FontSize',14);
% ylabel('Permuted runs','FontSize',14);
% title('p<0.0001')

myStats = struct();
myStats.PCTVAR = PCTVAR;
myStats.PCTVAR_PEM = PCTVAR_PEM;
myStats.Rsquared = Rsquared;
myStats.Rsq_PEM = Rsq;
myStats.P = p;






